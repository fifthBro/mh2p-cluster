#!/bin/ksh
# Copyright (c) 2026 fifthBro (https://github.com/fifthBro/mh2p-androidauto-cluster)
# This file is licensed under CC BY-NC-SA 4.0.
# https://creativecommons.org/licenses/by-nc-sa/4.0/
# See the LICENSE file in the project root for full license text.
# NOT FOR COMMERCIAL USE

# backup

export MOD_PATH=$modPath

[[ ! -e "/mnt/app" ]] && mount -t qnx6 /dev/mnanda0t177.1 /mnt/app
mount -uw /mnt/app/

export RELEASE_VERSION=`/mnt/app/armle/usr/bin/pc b:46924065:401 | cut -c 61- | sed ':a;N;$!ba;s/\n//g' | sed -e 's/\.//g' | sed -e 's/ //g'`
# AS, CN, ER, US, ...
export REGION="$(echo $RELEASE_VERSION | cut -d'_' -f2)"
# VW, AU, PO, LB, ...
export OEM="$(echo $RELEASE_VERSION | cut -d'_' -f3 | cut -b -2)"
# 416, 636, G33, G35, G36, ...
export TYPE="$(echo $RELEASE_VERSION | cut -d'_' -f3 | cut -b 3-)"
# E: engineering, K: customer update, P: production, S: security update
export RELEASE_TYPE="$(echo $RELEASE_VERSION | cut -d'_' -f4 | cut -b -1)"
# 9830, 2870, ...
export SOFTWARE_VERSION="$(echo $RELEASE_VERSION | cut -d'_' -f4 | cut -b 2-)"

if [ "$OEM" = "PO" ]; then
    echo "Porsche detected, Installing Android Auto Cluster integration"
    
    # config 
    TARGET_DIR="/mnt/app/eso/hmi/lsd/jars"
    TARGET_GLOB="$TARGET_DIR/AndroidAutoCluster_*"

    MOD_PATH="${MOD_PATH:-}"
    [[ -z "$MOD_PATH" ]] && { print -u2 "ERROR: No MOD_PATH setting"; exit 1; }

    BACKUP_DIR="$MOD_PATH/Backup"
    mkdir -p "$BACKUP_DIR" || { print -u2 "ERROR: cannot create $BACKUP_DIR"; exit 2; }

    # pick newest new jar 
    NEW_JAR="$(ls -1t "$MOD_PATH"/AndroidAutoCluster_* 2>/dev/null | head -1)"
    [[ -z "$NEW_JAR" || ! -f "$NEW_JAR" ]] && {
        print -u2 "ERROR: No new jar found at $MOD_PATH/AndroidAutoCluster_*"
        exit 3
    }

    NEW_BASE="${NEW_JAR##*/}"
    TARGET_JAR="$TARGET_DIR/$NEW_BASE"

    ts() { date +"%Y%m%d_%H%M%S"; }

    # backup any existing AndroidAutoClusterjars
    typeset j dst
    for j in $TARGET_GLOB; do
        if [[ -f "$j" ]]; then
            dst="$BACKUP_DIR/${j##*/}.backup.$(ts)"
            if cp -p "$j" "$dst"; then
                rm -f "$j"
                print "Backed up and removed: $j -> $dst"
            else
                print -u2 "ERROR: backup failed, not removing: $j"
                exit 1
            fi
        fi
    done
      
    # copy new jar
    cp -p "$NEW_JAR" "$TARGET_JAR" || { print -u2 "Copy failed"; exit 4; }
    
    print "Done."
    print "New jar:    $NEW_JAR"
    print "Target jar: $TARGET_JAR"
    print "Backups:    $BACKUP_DIR"


fi
