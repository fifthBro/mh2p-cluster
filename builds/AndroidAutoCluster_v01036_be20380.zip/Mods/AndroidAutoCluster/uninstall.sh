#!/bin/ksh
# Copyright (c) 2026 fifthBro (https://github.com/fifthBro/mh2p-androidauto-cluster)
# This file is licensed under CC BY-NC-SA 4.0.
# https://creativecommons.org/licenses/by-nc-sa/4.0/
# See the LICENSE file in the project root for full license text.
# NOT FOR COMMERCIAL USE

set -eu

export MOD_PATH=$modPath

[[ ! -e "/mnt/app" ]] && mount -t qnx6 /dev/mnanda0t177.1 /mnt/app
mount -uw /mnt/app/

export RELEASE_VERSION=`/mnt/app/armle/usr/bin/pc b:46924065:401 | cut -c 61- | sed ':a;N;$!ba;s/\n//g' | sed -e 's/\.//g' | sed -e 's/ //g'`
# AS, CN, ER, US, ...
export REGION="$(echo $RELEASE_VERSION | cut -d'_' -f2)"
# VW, AU, PO, LB, ...
export OEM="$(echo $RELEASE_VERSION | cut -d'_' -f3 | cut -b -2)"
# 416, 636, G33, G35, G36, ...
export TYPE="$(echo $RELEASE_VERSION | cut -d'_' -f3 | cut -b 3-)"
# E: engineering, K: customer update, P: production, S: security update
export RELEASE_TYPE="$(echo $RELEASE_VERSION | cut -d'_' -f4 | cut -b -1)"
# 9830, 2870, ...
export SOFTWARE_VERSION="$(echo $RELEASE_VERSION | cut -d'_' -f4 | cut -b 2-)"

# Uninstall Android Auto Cluster integration 

if [ "$OEM" = "PO" ]; then

    echo "Porsche detected, checking if Android Auto Cluster integration was installed"
    
    # config 
    TARGET_GLOB="/mnt/app/eso/hmi/lsd/jars/AndroidAutoCluster_*"
    MOD_PATH="${MOD_PATH:-}"

    MOD_PATH="${MOD_PATH:-}"
    [[ -z "$MOD_PATH" ]] && { print -u2 "ERROR: Set MOD_PATH"; exit 1; }

    BACKUP_DIR="$MOD_PATH/Backup"
    mkdir -p "$BACKUP_DIR"

    ts() { date +"%Y%m%d_%H%M%S"; }
    
    # remove any existing AndroidAutoClusterjars
    typeset j dst
    for j in $TARGET_GLOB; do
        if [[ -f "$j" ]]; then
            dst="$BACKUP_DIR/${j##*/}.removed.$(ts)"
            # backup; only delete if backup succeeded
            if cp -p "$j" "$dst"; then
                rm -f "$j"
                print "Backed up and removed: $j -> $dst"
            else
                print -u2 "ERROR: backup failed, not removing: $j"
            exit 1
            fi
        fi
    done
    print "Done."
fi
