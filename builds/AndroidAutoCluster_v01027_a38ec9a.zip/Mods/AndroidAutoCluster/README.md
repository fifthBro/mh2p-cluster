# AndroidAutoCluster 
https://github.com/fifthBro/mh2p-androidauto-cluster

AndroidAutoCluster integrates Android Auto navigation with Porsche PCM5/MH2P instrument cluster display via the BAP. 
 - It receives Android Auto navigation events via DSI interface
 - Converts them to BAP format (mainElement, direction, distance, bargraph etc.)
 - Calls CombiBAPServiceNavi methods to send to cluster

## License

 - Licensed under CC BY-NC-SA 4.0.
 - https://creativecommons.org/licenses/by-nc-sa/4.0/
 - See the LICENSE file in the project root for full license text.
 - NOT FOR COMMERCIAL USE

## Configuration

### Config Sources (priority order)

 - External config: USB/SD card (androidauto_cluster_config.json)
 - Embedded config: JAR resource (/androidauto_cluster_config.json)
 - Default values (as below)

### Code defaults: Hardcoded fallback values
{
  "config": {
    "enableFileLogging": true,
    "enableFileHashing": false,
    "enableExternalLogging": false,
    "enableRoundaboutLatching": true,
    "forceImperial": false,
    "forceRHD": false,
    "logFilePath": "/tmp/androidauto_cluster.log",
    "hashedLogFilePath": "/tmp/androidauto_cluster_hashed.log"
  },
  "buildVersion": "__VERSION__"
}

## Logging

### Dual logging
- Regular logs: Full navigation and system events - only created when enableFileLogging : true
- Hashed logs: Sanitized logs with PII replaced by hash values (road names, music metadata) - only created when enableFileHashing: true

### Log path selection

- Default: /tmp/androidauto_cluster.log and /tmp/androidauto_cluster_hashed.log
- Configurable: Custom paths can be set via logFilePath and hashedLogFilePath in config
- External Storage: Automatically uses USB/SD when available (if enableExternalLogging: true)
- Priority: USB0 → USB1 → SDA → SDB → configured fallback
- Auto-mount: Attempts read-write mount via StorageMountHandler
- Fallback to logFilePath from androidauto_cluster_config.json -> default value 

### Log Management

- Size limit: 1MB per file (auto-truncates when exceeded)
- Session correlation: Unique session ID markers for matching regular/hashed logs
- Path override logging: Reports when external storage is used

## LHD/RHD (Drive Side) and Metric/Imperial Unit Detection

## Car Properties (Primary Source)

 - Uses ICarCoreServices.configuration().exteriorLight().leftHandTraffic() to detect vehicle configuration 
 - Uses  ISysServices.units().distance() and units().speed() for current unit settings
 - Direct hardware/firmware detection from vehicle's GPS position and configuration so should be the most reliable method
 
## Country-based Fallback

 - Used when car properties are unavailable or unreliable
 - JSON config contains country database with rhd and unit boolean property
 - Example for drive side: "GB": {"rhd": true}, "US": {"rhd": false}
 - Example for unit: "US": {"imperial": true}, "AU": {"imperial": false}

### Default Fallback

Falls back to metric (imperial = false) and lhd (rhd = false) if no detection method succeeds

### Force Override:

 - Allows manual override for edge cases or testing
 - forceRHD and forceImperial config options will bypass all detection 

## Troubleshooting & Bug Reports

### Get an SD card 

 - 1GB is more than enough and format it FAT32.

### Extract androidauto_cluster_config.json 
- Open the AndroidAutoCluster jar file  (it’s just a zip) with your tool of choice, WinZip / 7-Zip / any zip tool, or jar/zip tooling if you prefer command line.

### Enable logging
Edit the following options in androidauto_cluster_config.json
    "enableFileLogging": true,
    "enableFileHashing": true,
    "enableExternalLogging": true,
Save androidauto_cluster_config.json to root directory of the SD card

### Capturing the data 

 - Insert the SD card into the MH2p/PCM5 before starting the car / booting the unit.
 - After your drive/session, pull the SD card and examine the logs (per the guidance below).

### If the cluster display shows incorrect information:

 - Note what the navigation app (Google Maps/Waze) is showing in the infotainment system
 - After your session, remove the SD card and locate the relevant log entries using session timestamps
 - Match the regular log entries to the corresponding hashed log file using the session ID
 - Send the hashed log excerpts along with a description of the expected vs. actual cluster behavior

## Known Limitations & Caveats

### Incomplete Testing

 - LHD/RHD (left/right-hand drive) detection and routing may not work correctly 
 - Imperial vs. metric unit conversion is not fully tested across 

### Roundabout Handling

 - Waze doesn't provide exit angles, only sequential numbers (0, 1, 2...)
 - Logic assumes standard 4-exit roundabouts, which may be incorrect for complex intersections
 - All roundabout updates send to cluster are too slow to be useful during navigation, "enableRoundaboutLatching" is enabled by default to show the initial exit rather than updating as you progress through the roundabout

### Data Quality Issues

 - Some navigation glitches are caused by poor data quality from Google Maps and Waze to the cluster 
 - The graniularity of data is not comparable to what these Waze and GoogleMap use internally for turn-by-turn guidance or route visualization
 - Display updates are slow (bargraph movement) due to Android Auto sending very infreqeunt updates, not the cluster integration

### General Notes

 - Some niche bugs and glitches will be addressed in future updates
 - Others are inherent limitations of the Android Auto data interface and cannot be resolved at the cluster level

