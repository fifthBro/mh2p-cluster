# Android Auto and CarPlay Cluster Integration
(C) 2026 fifthBro https://fifthbro.github.io

## Overview

Translates Android Auto and Carplay navigation events into BAP (Bedien-und Anzeigeprotokoll) messages for real-time turn-by-turn navigation on your instrument cluster. Native navigation monopolizes the cluster — this changes that.

- Intercepts Android Auto navigation events via DSI and Carplay via RGI 
- Converts them to BAP protocol messages
- Sends to cluster via `CombiBAPServiceNavi`
- Overrides native navigation with configurable heartbeat (default 2s)
- Supports both Google Maps, Waze and AppleMaps

## Features

- **Full navigation support** — turn arrows, distance, road names, roundabouts, highway exits
- **Real-time updates** — proximity-zone throttling (veryFar→now) with heartbeat to override native nav
- **Unit detection** — automatic km/mi and LHD/RHD detection via platform services with JSON country fallback (60+ countries)
- **JSON configuration** — runtime-configurable without recompilation; override via USB/SD card
- **Comprehensive logging** — dual-timestamp log with optional privacy hashing and external USB/SD output
- **Java 1.4 compatible** — runs on the embedded QNX/OSGI platform without modern Java features

## Changelog

### Beta candidate
Testing compatibility across Porsche Cayenne, Macan, Panamera and 911.

## Credits
- **LukaDev** — Managing screens in VW/MIB2 and CarPlay RGI and GAL hacking: https://github.com/luka-dev/mib2q-carplay-rgi/
- **One1Blt** — Android Auto/VNC to MIB2 rendering: https://github.com/OneB1t/VcMOSTRenderMqb
- **adi961** — Turn-by-turn to VC integration: https://github.com/adi961/mib2-android-auto-vc
- **LawPaul** — MH2P Modkit: https://lawpaul.github.io/MH2p_SD_ModKit_Site/
- **litdreams10** — General platform knowledge, Android Auto testing

*Not affiliated with Porsche, Volkswagen, Audi, or Google. This software is free and not for commercial use.*
